<?php
	$dbc=mysqli_connect('localhost','root','root','intrdbproj');

	if (!$dbc) {
		die('Could not connect: '.mysql_error());
	}
?>

